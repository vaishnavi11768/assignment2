const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const User = require("../models/User");

const authMiddleware = require("../middleware/authMiddleware");

const roleMiddleware = require("../middleware/roleMiddleware");

const router = express.Router();


// REGISTER
router.post("/register", async (req, res) => {

  try {

    const { name, email, password, role } = req.body;

    const existingUser = await User.findOne({ email });

    if (existingUser) {

      return res.status(400).json({
        message: "User already exists",
      });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const user = await User.create({
      name,
      email,
      password: hashedPassword,
      role,
    });

    res.status(201).json({
      message: "User registered",
      user,
    });

  } catch (error) {

    res.status(500).json({
      message: error.message,
    });
  }
});



// LOGIN
router.post("/login", async (req, res) => {

  try {

    const { email, password } = req.body;

    const user = await User.findOne({ email });

    if (!user) {

      return res.status(400).json({
        message: "Invalid credentials",
      });
    }

    const isMatch = await bcrypt.compare(password, user.password);

    if (!isMatch) {

      return res.status(400).json({
        message: "Invalid credentials",
      });
    }

    const token = jwt.sign(
      {
        id: user._id,
        role: user.role,
      },
      process.env.JWT_SECRET,
      {
        expiresIn: "1d",
      }
    );

    res.json({
      token,
    });

  } catch (error) {

    res.status(500).json({
      message: error.message,
    });
  }
});



// PROFILE
router.get(
  "/profile",
  authMiddleware,
  roleMiddleware("student", "admin"),
  async (req, res) => {

    try {

      const user = await User.findById(req.user.id)
        .select("-password");

      res.json(user);

    } catch (error) {

      res.status(500).json({
        message: error.message,
      });
    }
  }
);



// ADMIN
router.get(
  "/admin",
  authMiddleware,
  roleMiddleware("admin"),
  async (req, res) => {

    const users = await User.find();

    res.json(users);
  }
);



// STUDENT
router.get(
  "/student",
  authMiddleware,
  roleMiddleware("student", "admin"),
  async (req, res) => {

    res.json({
      message: "Student Dashboard",
    });
  }
);
router.delete(
  "/delete/:id",
  authMiddleware,
  roleMiddleware("admin"),
  async (req, res) => {

    try {

      await User.findByIdAndDelete(req.params.id);

      res.json({
        message: "User deleted successfully"
      });

    } catch (error) {

      res.status(500).json({
        message: error.message
      });
    }
  }
);
module.exports = router;